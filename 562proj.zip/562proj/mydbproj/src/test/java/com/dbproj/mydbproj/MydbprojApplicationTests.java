package com.dbproj.mydbproj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MydbprojApplicationTests {

    @Test
    void contextLoads() {
    }

}
